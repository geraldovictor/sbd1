#include <stdio.h>
#include <stdlib.h>

struct carro{
    char modelo[20];
    char marca[20];
    char renavam[11];
    char cor[10];
};

struct proprietario{
    char nome[20];
    char cpf[11];
    char data_nascimento[8];
    int qtd_carro;
    struct carro Carro;
};


void abre(FILE** arq){
    *arq = fopen("relatorio.txt", "a");
}


int main(void){
    struct proprietario p1;
    struct carro c;
    FILE* arq = NULL;
    int i = 0;

    abre(&arq);
  
    printf("Insira nome, CPF, data de nascimento e sua quantidade de carros\n");
    scanf("%s %s %s %d", p1.nome, p1.cpf, p1.data_nascimento, &p1.qtd_carro); 
    fprintf(arq, "Nome: %s\n CPF: %s\n Nasc: %s\n", p1.nome, p1.cpf, p1.data_nascimento);

    printf("Cadastre seu carro\n");
    for(i=1; i<= p1.qtd_carro; i++){
        printf("Insira Cor, Marca, Modelo e Renavam do carro nº:%d\n");
        scanf("%s %s %s %s", c.cor, c.marca, c.modelo, c.renavam);
        fprintf(arq, "Carro nº:%d\n Cor:%s\n Marca:%s\n Modelo:%s\n Renavam:%s \n\n", i, c.cor, c.marca, c.modelo, c.renavam);
    }
    
    printf("Dados salvos no arquivo com sucesso!\n");

    fclose(arq);

    return 0;
}